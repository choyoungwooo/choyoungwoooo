package class1.example2;

public class ProducOrder {
    String productName;
    int price;
    int quantity;
}
