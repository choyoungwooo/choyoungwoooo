package class1.example;

public class MovieReview {
    public String title;
    public String review;
}
