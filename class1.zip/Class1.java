package class1;

public class Class1 {
    public static void main(String[] args) {
        String sutdent1Name = "학생1";
        int sutdent1Age = 15;
        int student1Grade = 90;

        String sutdent2Name = "학생2";
        int sutdent2Age = 16;
        int student2Grade = 80;

        String sutdent3Name = "학생3";
        int sutdent3Age = 12;
        int student3Grade = 70;


        System.out.println("이름 : "+sutdent1Name+" 나이 :" +sutdent1Age+ " 학년 : "+student1Grade);
        System.out.println("이름 : "+sutdent2Name+" 나이 :" +sutdent2Age+ " 학년 : "+student2Grade);
        System.out.println("이름 : "+sutdent3Name+" 나이 :" +sutdent3Age+ " 학년 : "+student3Grade);
    }
}
